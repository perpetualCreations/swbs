"""
Socket Wrapper for Byte Strings (SWBS)
Made by perpetualCreations
"""

from swbs import objects, configure, errors, interface
